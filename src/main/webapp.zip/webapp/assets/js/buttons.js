<button id="myButton" className="float-left submit-button">Home</button>

<script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
    location.href = "www.yoursite.com"};
</script>