async function fetch_data(){

  
    let response = await fetch('http://localhost:8080/ERP-1.0-SNAPSHOT/api/organisation/get');
    let result = await response.json();
    console.log(result);

    let table_data = document.getElementById('myTable');
    table_data.innerHTML = '';

    for (let i = 0; i < result.length; i++) {
        //<th scope="row">'+(i+1)+'</th>\n
        let organisationID = document.createElement('tr');
        organisationID.innerHTML= //'<th scope="row"></th>\n' +
            '               <td>'+result[i]['organisationID']+'</td>\n'+
            '               <td>'+result[i]['organisationName']+'</td>\n' +
            '               <td>'+result[i]['organisationAddress']+'</td>\n';
        table_data.appendChild(organisationID);

    }

}